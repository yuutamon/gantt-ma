"""
Django settings for config project.

Django 5.2 / Django REST Framework によるガントチャート用バックエンド。

主な要件への対応:
- ログイン必須 (SessionAuthentication + IsAuthenticated)
- ページサイズ 50 のページング (DRF PageNumberPagination)
- 外部データ取得を想定した 5 秒遅延データソース
- ユーザー単位のキャッシュ (キャッシュキーに user.pk を含める)
"""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-ylemh@#h1@2k4l0+%j0^32*e8^njqzjewu3rvvaa@9p8pt#j*d'

DEBUG = True

# 開発用: サンドボックスのプロキシドメインからのアクセスを許可
ALLOWED_HOSTS = ['*']


# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    # third party
    'rest_framework',
    'corsheaders',
    # local
    'gantt',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    # CORS は CommonMiddleware より前に置く
    'corsheaders.middleware.CorsMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'config.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'config.wsgi.application'


# Database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}


# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]


# Internationalization
LANGUAGE_CODE = 'ja'
TIME_ZONE = 'Asia/Tokyo'
USE_I18N = True
USE_TZ = True


# Static files
STATIC_URL = 'static/'
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'


# ---------------------------------------------------------------------------
# Django REST Framework
# ---------------------------------------------------------------------------
REST_FRAMEWORK = {
    # ログイン必須: 認証されていなければ 403/401 を返す
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.SessionAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
    # ページング: ページサイズ 50
    'DEFAULT_PAGINATION_CLASS': 'gantt.pagination.GanttPageNumberPagination',
    'PAGE_SIZE': 50,
}


# ---------------------------------------------------------------------------
# キャッシュ
#   - 開発環境ではローカルメモリキャッシュを使用
#   - 本番では Redis / Memcached 等に差し替え可能
#   - キャッシュキーには必ず user.pk を含めることで「ユーザー単位」を担保し、
#     全ユーザーが同じキャッシュを参照しないようにする (views.py 参照)
# ---------------------------------------------------------------------------
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'gantt-cache',
        'TIMEOUT': 60 * 30,  # 30 分
    }
}


# ---------------------------------------------------------------------------
# CORS / CSRF (開発用)
# ---------------------------------------------------------------------------
CORS_ALLOW_ALL_ORIGINS = True
CORS_ALLOW_CREDENTIALS = True
CSRF_TRUSTED_ORIGINS = [
    'http://localhost:5173',
    'http://127.0.0.1:5173',
]
# 開発用: クロスサイトでも Cookie を送れるよう緩める
SESSION_COOKIE_SAMESITE = 'Lax'
CSRF_COOKIE_SAMESITE = 'Lax'
