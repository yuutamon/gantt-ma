"""URL ルーティング。"""

from django.contrib import admin
from django.urls import path

from gantt import auth_views, views

urlpatterns = [
    path('admin/', admin.site.urls),

    # 認証
    path('api/auth/csrf/', auth_views.CSRFView.as_view()),
    path('api/auth/login/', auth_views.LoginView.as_view()),
    path('api/auth/logout/', auth_views.LogoutView.as_view()),
    path('api/auth/me/', auth_views.MeView.as_view()),

    # ガントチャートデータ (ログイン必須・ページング・ユーザー単位キャッシュ)
    path('api/gantt/groups/', views.GroupListView.as_view()),
    path('api/gantt/items/', views.ItemListView.as_view()),
    path('api/gantt/page/', views.GanttPageView.as_view()),
    path('api/gantt/cache/clear/', views.CacheInvalidateView.as_view()),
]
