"""
セッション認証用のシンプルなエンドポイント。

- GET  /api/auth/csrf/    : CSRF Cookie をセット
- POST /api/auth/login/   : username / password でログイン
- POST /api/auth/logout/  : ログアウト
- GET  /api/auth/me/      : 現在のログインユーザー情報
"""

from django.contrib.auth import authenticate, login, logout
from django.middleware.csrf import get_token
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView


class CSRFView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        return Response({'csrfToken': get_token(request)})


class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(request, username=username, password=password)
        if user is None:
            return Response({'detail': 'ユーザー名またはパスワードが正しくありません。'}, status=400)
        login(request, user)
        return Response({'id': user.pk, 'username': user.username})


class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        logout(request)
        return Response({'detail': 'logged out'})


class MeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response({'id': request.user.pk, 'username': request.user.username})
