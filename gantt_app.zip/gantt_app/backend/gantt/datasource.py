"""
外部データソースの抽象。

要件:
- 将来的に外部 API からデータを取得することを想定している。
- 現時点では外部取得は不要だが、取得には 5 秒ほどかかると想定する。
- そのため、本モジュールでは「5 秒かかる重い取得処理」をシミュレートし、
  views 側でユーザー単位キャッシュを掛けることで 2 回目以降は高速化する。

実運用では fetch_groups / fetch_items の中身を、外部 API 呼び出しや
DB からの集計処理に置き換えればよい。インターフェース（返り値の形）は
そのまま維持できる。
"""

import time

from .models import Group, Item
from .serializers import GroupSerializer, ItemSerializer

# 外部取得にかかると想定する遅延（秒）
SIMULATED_FETCH_DELAY = 5


def fetch_groups(user):
    """指定ユーザーの全 groups を「重い処理」として取得する。

    実際には外部 API を叩く想定。ここでは 5 秒の遅延でシミュレートし、
    DB から owner=user の groups を読み出して vis.js 形式の list を返す。
    """
    time.sleep(SIMULATED_FETCH_DELAY)
    qs = Group.objects.filter(owner=user).order_by('order', 'id')
    return GroupSerializer(qs, many=True).data


def fetch_items(user):
    """指定ユーザーの全 items を「重い処理」として取得する。"""
    time.sleep(SIMULATED_FETCH_DELAY)
    qs = Item.objects.filter(owner=user).order_by('start', 'id')
    return ItemSerializer(qs, many=True).data
