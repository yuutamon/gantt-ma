"""
デモ用データ投入コマンド。

レンダリングに時間がかかる状況（大量の groups / items）を再現するため、
デフォルトで多めのデータを生成する。

    python manage.py seed_demo --username demo --password demo12345 \
        --groups 300 --items-per-group 5
"""

import random
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.utils import timezone

from gantt.models import Group, Item


class Command(BaseCommand):
    help = 'デモユーザーとガントチャート用データを生成する'

    def add_arguments(self, parser):
        parser.add_argument('--username', default='demo')
        parser.add_argument('--password', default='demo12345')
        parser.add_argument('--groups', type=int, default=300)
        parser.add_argument('--items-per-group', type=int, default=5)

    def handle(self, *args, **opts):
        User = get_user_model()
        user, created = User.objects.get_or_create(username=opts['username'])
        user.set_password(opts['password'])
        user.is_staff = True
        user.is_superuser = True
        user.save()

        # 既存データをクリア
        Item.objects.filter(owner=user).delete()
        Group.objects.filter(owner=user).delete()

        base = timezone.now().replace(hour=0, minute=0, second=0, microsecond=0)
        n_groups = opts['groups']
        n_items = opts['items_per_group']

        groups = []
        for i in range(n_groups):
            groups.append(Group(owner=user, content=f'リソース {i + 1:03d}', order=i))
        Group.objects.bulk_create(groups)
        groups = list(Group.objects.filter(owner=user).order_by('order', 'id'))

        items = []
        for gi, g in enumerate(groups):
            cursor = base - timedelta(days=random.randint(0, 10))
            for j in range(n_items):
                duration = random.randint(1, 7)
                start = cursor + timedelta(days=random.randint(1, 4))
                end = start + timedelta(days=duration)
                items.append(Item(
                    owner=user,
                    group=g,
                    content=f'タスク {gi + 1}-{j + 1}',
                    start=start,
                    end=end,
                ))
                cursor = end
        Item.objects.bulk_create(items)

        self.stdout.write(self.style.SUCCESS(
            f'ユーザー "{user.username}" / groups={len(groups)} / items={len(items)} を作成しました。'
        ))
