"""
ガントチャート用モデル。

vis.js Timeline は `groups`（縦軸の行）と `items`（バー）を必要とする。
ここではユーザーごとにデータを分離するため、両モデルに owner を持たせている。
"""

from django.conf import settings
from django.db import models


class Group(models.Model):
    """vis.js Timeline の groups に対応する縦軸の行。"""

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='gantt_groups',
    )
    content = models.CharField(max_length=255)  # 行ラベル
    order = models.IntegerField(default=0)  # 並び順

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return f'{self.content} (owner={self.owner_id})'


class Item(models.Model):
    """vis.js Timeline の items に対応するバー(タスク)。"""

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='gantt_items',
    )
    group = models.ForeignKey(
        Group,
        on_delete=models.CASCADE,
        related_name='items',
    )
    content = models.CharField(max_length=255)  # バーのラベル
    start = models.DateTimeField()
    end = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['start', 'id']

    def __str__(self):
        return f'{self.content} (owner={self.owner_id})'
