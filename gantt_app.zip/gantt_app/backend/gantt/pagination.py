"""
ガントチャート用ページング。

ページサイズは 50 固定（要件）。
フロントの無限スクロールで扱いやすいよう、レスポンスには
次/前ページの有無と現在ページ番号を含める。
"""

from collections import OrderedDict

from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response


class GanttPageNumberPagination(PageNumberPagination):
    page_size = 50  # 要件: ページサイズ 50
    page_size_query_param = 'page_size'
    max_page_size = 200

    def get_paginated_response(self, data):
        return Response(OrderedDict([
            ('count', self.page.paginator.count),
            ('total_pages', self.page.paginator.num_pages),
            ('current_page', self.page.number),
            ('page_size', self.get_page_size(self.request)),
            ('has_next', self.page.has_next()),
            ('has_previous', self.page.has_previous()),
            ('next', self.get_next_link()),
            ('previous', self.get_previous_link()),
            ('results', data),
        ]))
