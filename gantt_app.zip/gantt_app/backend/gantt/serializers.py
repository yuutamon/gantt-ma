"""
vis.js Timeline がそのまま読み込める形に整形するシリアライザ。

vis.js の DataSet は最低限 `id` を必要とし、
- groups: { id, content }
- items : { id, group, content, start, end }
の形を取る。
"""

from rest_framework import serializers

from .models import Group, Item


class GroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = Group
        fields = ['id', 'content', 'order']


class ItemSerializer(serializers.ModelSerializer):
    # vis.js では group プロパティが groups の id を指す
    group = serializers.IntegerField(source='group_id')

    class Meta:
        model = Item
        fields = ['id', 'group', 'content', 'start', 'end']
