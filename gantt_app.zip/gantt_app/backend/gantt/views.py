"""
ガントチャート API ビュー。

設計のポイント:
1. ログイン必須:
   IsAuthenticated を全ビューに適用。未ログインは 403 を返し、
   他ユーザーのデータは一切返さない（owner=request.user で絞る）。

2. 5 秒遅延データソース + ユーザー単位キャッシュ:
   datasource.fetch_* は 5 秒かかる重い処理。これを cache に保存するが、
   キャッシュキーに必ず request.user.pk を含めることで「ユーザー単位」を担保。
   これにより、あるユーザーのキャッシュが別ユーザーに見えることはない。
   2 回目以降の取得はキャッシュヒットで即時に返る。

3. ページング（ページサイズ 50）:
   - groups エンドポイント: groups を 50 件ずつ返す。
   - items エンドポイント : items を 50 件ずつ返す（単体利用も可能）。
   - page エンドポイント  : フロントの無限スクロール用。groups を 50 件ずつ
     返すと同時に、その 50 グループに属する items も同梱して返す。
     これにより「表示しているグループ行」と「そのバー」が常に一致し、
     大量データでも 1 ページ分だけ描画すればよくレンダリングが軽い。
"""

from django.core.cache import cache
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from . import datasource

PAGE_SIZE = 50
CACHE_TIMEOUT = 60 * 30  # 30 分


def _user_cache_key(user, kind):
    """ユーザー単位のキャッシュキー。user.pk を必ず含めて分離する。"""
    return f'gantt:{kind}:user:{user.pk}'


def _get_cached_dataset(user, kind, fetch_fn):
    """ユーザー単位キャッシュ付きでデータセット(list)を取得する。"""
    key = _user_cache_key(user, kind)
    data = cache.get(key)
    if data is None:
        data = fetch_fn(user)
        cache.set(key, data, CACHE_TIMEOUT)
    return data


def _read_page_params(request):
    try:
        page = int(request.query_params.get('page', 1))
    except (TypeError, ValueError):
        page = 1
    page = max(1, page)

    try:
        page_size = int(request.query_params.get('page_size', PAGE_SIZE))
    except (TypeError, ValueError):
        page_size = PAGE_SIZE
    page_size = max(1, min(page_size, 200))
    return page, page_size


def _slice(full_list, page, page_size):
    count = len(full_list)
    total_pages = (count + page_size - 1) // page_size if count else 1
    start = (page - 1) * page_size
    end = start + page_size
    return full_list[start:end], {
        'count': count,
        'total_pages': total_pages,
        'current_page': page,
        'page_size': page_size,
        'has_next': page < total_pages,
        'has_previous': page > 1,
    }


class GroupListView(APIView):
    """groups を 50 件ずつ返す。"""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        page, page_size = _read_page_params(request)
        full = _get_cached_dataset(request.user, 'groups', datasource.fetch_groups)
        results, meta = _slice(full, page, page_size)
        return Response({**meta, 'results': results})


class ItemListView(APIView):
    """items を 50 件ずつ返す（単体利用可）。"""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        page, page_size = _read_page_params(request)
        full = _get_cached_dataset(request.user, 'items', datasource.fetch_items)
        results, meta = _slice(full, page, page_size)
        return Response({**meta, 'results': results})


class GanttPageView(APIView):
    """無限スクロール用: groups を 50 件ずつ返し、その範囲の items を同梱する。

    レスポンス例:
    {
      "current_page": 1, "total_pages": 6, "page_size": 50,
      "has_next": true, "has_previous": false, "count": 300,
      "groups": [ {id, content, order}, ... 最大50件 ],
      "items":  [ {id, group, content, start, end}, ... 上記groupsに属するもの ]
    }
    """

    permission_classes = [IsAuthenticated]

    def get(self, request):
        page, page_size = _read_page_params(request)

        groups_full = _get_cached_dataset(request.user, 'groups', datasource.fetch_groups)
        items_full = _get_cached_dataset(request.user, 'items', datasource.fetch_items)

        group_page, meta = _slice(groups_full, page, page_size)
        group_ids = {g['id'] for g in group_page}
        item_page = [it for it in items_full if it['group'] in group_ids]

        return Response({
            **meta,
            'groups': group_page,
            'items': item_page,
        })


class CacheInvalidateView(APIView):
    """自分のキャッシュだけを破棄する（デモ/動作確認用）。"""

    permission_classes = [IsAuthenticated]

    def post(self, request):
        cache.delete(_user_cache_key(request.user, 'groups'))
        cache.delete(_user_cache_key(request.user, 'items'))
        return Response({'detail': 'cache cleared for current user'})
