import http from './http'

/** CSRF Cookie をセットする（ログイン前に呼ぶ）。 */
export async function fetchCsrf() {
  const { data } = await http.get('/auth/csrf/')
  return data
}

/** ログイン。 */
export async function login(username, password) {
  const { data } = await http.post('/auth/login/', { username, password })
  return data
}

/** ログアウト。 */
export async function logout() {
  const { data } = await http.post('/auth/logout/')
  return data
}

/** 現在のログインユーザーを取得。未ログインなら 403。 */
export async function fetchMe() {
  const { data } = await http.get('/auth/me/')
  return data
}

/**
 * groups をページ単位で取得。
 * @param {number} page 1始まりのページ番号
 */
export async function fetchGroups(page = 1, pageSize = 50) {
  const { data } = await http.get('/gantt/groups/', { params: { page, page_size: pageSize } })
  return data
}

/**
 * items をページ単位で取得。
 */
export async function fetchItems(page = 1, pageSize = 50) {
  const { data } = await http.get('/gantt/items/', { params: { page, page_size: pageSize } })
  return data
}

/**
 * 無限スクロール用: groups を 50 件と、その範囲に属する items を同時取得。
 * @param {number} page 1始まりのページ番号
 */
export async function fetchPage(page = 1, pageSize = 50) {
  const { data } = await http.get('/gantt/page/', { params: { page, page_size: pageSize } })
  return data
}

/** 自分のキャッシュをクリア（動作確認用）。 */
export async function clearCache() {
  const { data } = await http.post('/gantt/cache/clear/')
  return data
}
