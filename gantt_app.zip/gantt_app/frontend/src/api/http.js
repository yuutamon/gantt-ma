import axios from 'axios'

/**
 * axios インスタンス。
 * - withCredentials: セッション Cookie を送る（ログイン必須 API のため）
 * - Django の CSRF 方式に合わせ、csrftoken Cookie を X-CSRFToken ヘッダに付与
 */
const http = axios.create({
  baseURL: '/api',
  withCredentials: true,
  xsrfCookieName: 'csrftoken',
  xsrfHeaderName: 'X-CSRFToken',
})

export default http
