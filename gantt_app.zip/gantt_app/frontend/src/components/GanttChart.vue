<script setup>
/**
 * GanttChart — vis-timeline によるガントチャート表示コンポーネント（子）。
 *
 * 設計方針:
 * - 「表示」と「縦スクロール端の検知」に専念し、API は実行しない。
 *   親から groups / items を props で受け取り、上下端到達時に
 *   reach-top / reach-bottom を emit するだけ（API 実行は親が担う）。
 * - groups / items は必須 props。
 * - verticalScroll を有効化。vis-timeline は縦スクロールを
 *   `.vis-panel.vis-center` の scrollTop で表現するため、その要素の
 *   scroll/wheel イベントを監視して端到達を検知する。
 *   イベントが取りこぼされる環境向けに軽量ポーリングの保険も併用する。
 */
import { ref, onMounted, onBeforeUnmount, watch, nextTick } from 'vue'
import { Timeline } from 'vis-timeline/esnext'
import { DataSet } from 'vis-data/esnext'
import 'vis-timeline/styles/vis-timeline-graph2d.css'

const props = defineProps({
  groups: { type: Array, required: true },
  items: { type: Array, required: true },
  loadingTop: { type: Boolean, default: false },
  loadingBottom: { type: Boolean, default: false },
  threshold: { type: Number, default: 100 },
})

const emit = defineEmits(['reach-top', 'reach-bottom'])

const container = ref(null)
let timeline = null
let groupsDS = null
let itemsDS = null
let scrollEl = null
let didInitialFit = false
let lastEmitTop = 0
let lastEmitBottom = 0
let pollId = null
let lastScrollTop = -1

function toVisGroups(groups) {
  return groups.map((g) => ({ id: g.id, content: g.content }))
}
function toVisItems(items) {
  return items.map((it) => ({
    id: it.id,
    group: it.group,
    content: it.content,
    start: it.start,
    end: it.end || undefined,
  }))
}

function setInitialWindow() {
  // データ全体ではなく開始付近の約2週間を初期表示し、上部の空白を防ぐ。
  if (!props.items.length) return
  const starts = props.items
    .map((it) => new Date(it.start).getTime())
    .filter((t) => !Number.isNaN(t))
  if (!starts.length) return
  const min = Math.min(...starts)
  const start = new Date(min - 1000 * 60 * 60 * 24) // 1日前
  const end = new Date(min + 1000 * 60 * 60 * 24 * 14) // 14日後
  timeline.setWindow(start, end, { animation: false })
  didInitialFit = true
}

function buildTimeline() {
  groupsDS = new DataSet(toVisGroups(props.groups))
  itemsDS = new DataSet(toVisItems(props.items))

  const options = {
    stack: true,
    verticalScroll: true,
    horizontalScroll: true,
    zoomKey: 'ctrlKey',
    orientation: { axis: 'top' },
    height: '100%',
    maxHeight: '100%',
    margin: { item: 6, axis: 12 },
    tooltip: { followMouse: true },
  }

  timeline = new Timeline(container.value, itemsDS, groupsDS, options)
  setInitialWindow()

  timeline.on('changed', () => attachScrollListener())
  nextTick(() => {
    attachScrollListener()
    startPolling()
  })
}

function getScrollEl() {
  const root = container.value
  if (!root) return null
  return root.querySelector('.vis-panel.vis-center')
}

function attachScrollListener() {
  const el = getScrollEl()
  if (el && el !== scrollEl) {
    if (scrollEl) {
      scrollEl.removeEventListener('scroll', onScroll)
      scrollEl.removeEventListener('wheel', onScroll)
    }
    scrollEl = el
    scrollEl.addEventListener('scroll', onScroll, { passive: true })
    scrollEl.addEventListener('wheel', onScroll, { passive: true })
  }
}

// イベント取りこぼし対策の軽量ポーリング（scrollTop 変化時のみ評価）
function startPolling() {
  stopPolling()
  pollId = window.setInterval(() => {
    if (!scrollEl) {
      attachScrollListener()
      return
    }
    if (scrollEl.scrollTop !== lastScrollTop) {
      lastScrollTop = scrollEl.scrollTop
      evaluateEdges()
    }
  }, 250)
}
function stopPolling() {
  if (pollId) {
    window.clearInterval(pollId)
    pollId = null
  }
}

function onScroll() {
  // requestAnimationFrame でまとめて評価
  window.requestAnimationFrame(evaluateEdges)
}

function evaluateEdges() {
  if (!scrollEl) return
  const { scrollTop, scrollHeight, clientHeight } = scrollEl
  const now = Date.now()

  if (scrollHeight - (scrollTop + clientHeight) <= props.threshold) {
    if (now - lastEmitBottom > 500 && !props.loadingBottom) {
      lastEmitBottom = now
      emit('reach-bottom')
    }
  }
  if (scrollTop <= props.threshold) {
    if (now - lastEmitTop > 500 && !props.loadingTop) {
      lastEmitTop = now
      emit('reach-top')
    }
  }
}

/** 先頭にデータを足す際のスクロール位置補正用スナップショット。 */
function captureScroll() {
  const el = getScrollEl()
  if (!el) return null
  return { scrollTop: el.scrollTop, scrollHeight: el.scrollHeight }
}
function restoreScroll(snapshot) {
  if (!snapshot) return
  nextTick(() => {
    const el = getScrollEl()
    if (!el) return
    const delta = el.scrollHeight - snapshot.scrollHeight
    el.scrollTop = snapshot.scrollTop + delta
  })
}

defineExpose({ captureScroll, restoreScroll })

watch(
  () => props.groups,
  (newGroups) => {
    if (!groupsDS) return
    groupsDS.update(toVisGroups(newGroups))
  }
)

watch(
  () => props.items,
  (newItems) => {
    if (!itemsDS) return
    itemsDS.update(toVisItems(newItems))
    if (!didInitialFit && newItems.length && timeline) {
      setInitialWindow()
    }
    nextTick(attachScrollListener)
  }
)

onMounted(buildTimeline)
onBeforeUnmount(() => {
  stopPolling()
  if (scrollEl) {
    scrollEl.removeEventListener('scroll', onScroll)
    scrollEl.removeEventListener('wheel', onScroll)
  }
  if (timeline) timeline.destroy()
})
</script>

<template>
  <div class="gantt-wrapper">
    <div v-if="loadingTop" class="edge-loader edge-top">
      <v-progress-circular indeterminate size="20" width="2" color="primary" />
      <span class="ml-2 text-caption">前のデータを読み込み中…</span>
    </div>
    <div ref="container" class="gantt-container"></div>
    <div v-if="loadingBottom" class="edge-loader edge-bottom">
      <v-progress-circular indeterminate size="20" width="2" color="primary" />
      <span class="ml-2 text-caption">次のデータを読み込み中…</span>
    </div>
  </div>
</template>

<style scoped>
.gantt-wrapper {
  position: relative;
  height: 100%;
  display: flex;
  flex-direction: column;
}
.gantt-container {
  flex: 1 1 auto;
  min-height: 0;
}
.edge-loader {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 6px;
  background: rgba(255, 255, 255, 0.92);
  position: absolute;
  left: 0;
  right: 0;
  z-index: 5;
}
.edge-top { top: 0; }
.edge-bottom { bottom: 0; }
</style>
