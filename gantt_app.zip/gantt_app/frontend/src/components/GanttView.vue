<script setup>
/**
 * GanttView — ガントチャートの親コンポーネント。
 *
 * 責務（要件対応）:
 * - API の実行はこの親が担う（useQuery を使って /gantt/page/ を取得）。
 * - 1 ページ = groups 50 件 + その範囲の items。
 *   useQuery でページ単位にキャッシュし、usePaginatedData で双方向に蓄積する。
 * - 取得済みの groups / items は保持し、新ページと「繋ぎ合わせて」連続表示する。
 * - 子コンポーネント GanttChart には groups / items を props で渡し、
 *   端到達イベント(reach-top / reach-bottom)を受けて追加ページを取得する。
 */
import { ref, onMounted } from 'vue'
import { useQuery } from '../composables/useQuery'
import { usePaginatedData } from '../composables/usePaginatedData'
import * as api from '../api/gantt'
import GanttChart from './GanttChart.vue'

const chartRef = ref(null)
const status = ref('準備中…')
const initialLoading = ref(true)

// useQuery 経由でページを取得（親が API を実行する）。
// ページ単位でキャッシュされるため、一度見たページの再取得は即時。
function fetchGanttPage(page) {
  const q = useQuery({
    key: () => ['gantt-page', page],
    queryFn: () => api.fetchPage(page, 50),
    staleTime: 60 * 1000,
  })
  return q.execute()
}

const paged = usePaginatedData(fetchGanttPage)

function updateStatus() {
  status.value =
    `groups: ${paged.groups.value.length}/${paged.totalGroups.value ?? '-'} 件` +
    ` / items: ${paged.items.value.length} 件` +
    ` / ページ ${paged.minPage.value}〜${paged.maxPage.value}（全 ${paged.totalPages.value}）`
}

function getStartPage() {
  // 検証用: ?start=3 のように開始ページを指定可能（既定は 1）。
  const sp = new URLSearchParams(window.location.search).get('start')
  const n = parseInt(sp || '1', 10)
  return Number.isFinite(n) && n >= 1 ? n : 1
}

async function init() {
  initialLoading.value = true
  status.value = 'データ取得中（初回は外部取得想定で約5秒かかります）…'
  await paged.loadInitial(getStartPage())
  initialLoading.value = false
  updateStatus()
}

// 子から「最下部に到達」→ 次ページを取得して末尾に追加
async function onReachBottom() {
  if (!paged.hasNext.value || paged.isLoading.value) return
  await paged.loadNext()
  updateStatus()
}

// 子から「最上部に到達」→ 前ページを取得して先頭に追加（スクロール位置を補正）
async function onReachTop() {
  if (!paged.hasPrev.value || paged.isLoading.value) return
  const snapshot = chartRef.value?.captureScroll()
  const added = await paged.loadPrev()
  if (added > 0) chartRef.value?.restoreScroll(snapshot)
  updateStatus()
}

async function reload() {
  await api.clearCache().catch(() => {})
  await init()
}

onMounted(init)
</script>

<template>
  <div class="view-root">
    <v-toolbar density="comfortable" color="surface" flat class="px-2">
      <v-toolbar-title class="text-subtitle-1">ガントチャート</v-toolbar-title>
      <v-spacer />
      <span class="text-caption mr-4">{{ status }}</span>
      <v-btn
        size="small"
        variant="tonal"
        prepend-icon="mdi-refresh"
        :loading="paged.isLoading.value"
        @click="reload"
      >
        キャッシュ消去して再取得
      </v-btn>
    </v-toolbar>

    <div class="chart-area">
      <div v-if="initialLoading" class="center-loader">
        <v-progress-circular indeterminate color="primary" size="40" />
        <span class="mt-3 text-body-2">{{ status }}</span>
      </div>
      <GanttChart
        v-show="!initialLoading"
        ref="chartRef"
        :groups="paged.groups.value"
        :items="paged.items.value"
        :loading-top="paged.isLoadingPrev.value"
        :loading-bottom="paged.isLoadingNext.value"
        @reach-bottom="onReachBottom"
        @reach-top="onReachTop"
      />
    </div>
  </div>
</template>

<style scoped>
.view-root {
  height: 100%;
  display: flex;
  flex-direction: column;
}
.chart-area {
  flex: 1 1 auto;
  min-height: 0;
  border-top: 1px solid rgba(0, 0, 0, 0.08);
  position: relative;
}
.center-loader {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
</style>
