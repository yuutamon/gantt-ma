<script setup>
import { ref } from 'vue'
import { useAuthStore } from '../stores/auth'

const auth = useAuthStore()
const username = ref('demo')
const password = ref('demo12345')
const loading = ref(false)

async function submit() {
  loading.value = true
  await auth.login(username.value, password.value)
  loading.value = false
}
</script>

<template>
  <v-container class="fill-height" fluid>
    <v-row justify="center" align="center">
      <v-col cols="12" sm="8" md="4">
        <v-card class="pa-6" elevation="4">
          <v-card-title class="text-h6 mb-2">ログイン</v-card-title>
          <v-card-subtitle class="mb-4">
            ガントチャートの閲覧にはログインが必要です。
          </v-card-subtitle>
          <v-form @submit.prevent="submit">
            <v-text-field
              v-model="username"
              label="ユーザー名"
              prepend-inner-icon="mdi-account"
              variant="outlined"
              density="comfortable"
            />
            <v-text-field
              v-model="password"
              label="パスワード"
              type="password"
              prepend-inner-icon="mdi-lock"
              variant="outlined"
              density="comfortable"
            />
            <v-alert v-if="auth.loginError" type="error" density="compact" class="mb-3">
              {{ auth.loginError }}
            </v-alert>
            <v-btn type="submit" color="primary" block :loading="loading">ログイン</v-btn>
          </v-form>
          <p class="text-caption mt-4 text-medium-emphasis">
            デモ: demo / demo12345
          </p>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>
