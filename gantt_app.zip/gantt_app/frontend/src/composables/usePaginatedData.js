import { ref, computed } from 'vue'

/**
 * usePaginatedData — グループ連動ページング(/gantt/page/)の結果を
 * 「双方向に」蓄積するための composable。
 *
 * 仕様（要件対応）:
 * - 1 ページ = groups 最大 50 件 + それに属する items。
 * - スクロール最下部に到達 → 次ページを取得し、groups/items を末尾に追加。
 * - スクロール最上部に到達 → 前ページを取得し、groups/items を先頭に追加。
 * - 取得済みデータ(groups/items)は保持し、新データと「繋ぎ合わせて」連続表示する。
 * - 重複読み込み防止のためのローディングフラグと取得済みページ集合を管理。
 *
 * API を直接呼ばず、親から渡された fetchPage を用いる
 * （「API 実行は親コンポーネントから」を満たす）。
 *
 * @param {(page:number) => Promise<{groups:Array, items:Array, current_page:number, has_next:boolean, has_previous:boolean, total_pages:number, count:number}>} fetchPage
 */
export function usePaginatedData(fetchPage) {
  const groups = ref([])
  const items = ref([])
  const loadedPages = ref(new Set())
  const minPage = ref(null)
  const maxPage = ref(null)
  const totalPages = ref(null)
  const totalGroups = ref(null)
  const isLoadingNext = ref(false)
  const isLoadingPrev = ref(false)
  const error = ref(null)

  const hasNext = computed(() =>
    totalPages.value == null ? true : (maxPage.value == null || maxPage.value < totalPages.value)
  )
  const hasPrev = computed(() =>
    minPage.value == null ? false : minPage.value > 1
  )
  const isLoading = computed(() => isLoadingNext.value || isLoadingPrev.value)

  function mergeUnique(existing, incoming, atStart) {
    const seen = new Set(existing.map((x) => x.id))
    const filtered = incoming.filter((x) => !seen.has(x.id))
    return atStart ? [...filtered, ...existing] : [...existing, ...filtered]
  }

  function applyPage(page, atStart) {
    groups.value = mergeUnique(groups.value, page.groups, atStart)
    items.value = mergeUnique(items.value, page.items, atStart)
    loadedPages.value.add(page.current_page)
    totalPages.value = page.total_pages
    totalGroups.value = page.count
  }

  /** 初期ロード（指定ページから開始）。 */
  async function loadInitial(startPage = 1) {
    groups.value = []
    items.value = []
    loadedPages.value = new Set()
    minPage.value = null
    maxPage.value = null
    totalPages.value = null
    error.value = null

    isLoadingNext.value = true
    try {
      const page = await fetchPage(startPage)
      applyPage(page, false)
      minPage.value = page.current_page
      maxPage.value = page.current_page
    } catch (e) {
      error.value = e
      throw e
    } finally {
      isLoadingNext.value = false
    }
  }

  /** 次ページ（末尾に追加）。 */
  async function loadNext() {
    if (isLoading.value || !hasNext.value || maxPage.value == null) return
    const next = maxPage.value + 1
    if (loadedPages.value.has(next)) return
    isLoadingNext.value = true
    try {
      const page = await fetchPage(next)
      applyPage(page, false)
      maxPage.value = page.current_page
    } catch (e) {
      error.value = e
    } finally {
      isLoadingNext.value = false
    }
  }

  /** 前ページ（先頭に追加）。返り値は追加された groups 件数（位置補正用）。 */
  async function loadPrev() {
    if (isLoading.value || !hasPrev.value || minPage.value == null) return 0
    const prev = minPage.value - 1
    if (prev < 1 || loadedPages.value.has(prev)) return 0
    isLoadingPrev.value = true
    try {
      const before = groups.value.length
      const page = await fetchPage(prev)
      applyPage(page, true)
      minPage.value = page.current_page
      return groups.value.length - before
    } catch (e) {
      error.value = e
      return 0
    } finally {
      isLoadingPrev.value = false
    }
  }

  return {
    groups,
    items,
    minPage,
    maxPage,
    totalPages,
    totalGroups,
    hasNext,
    hasPrev,
    isLoading,
    isLoadingNext,
    isLoadingPrev,
    error,
    loadInitial,
    loadNext,
    loadPrev,
  }
}
