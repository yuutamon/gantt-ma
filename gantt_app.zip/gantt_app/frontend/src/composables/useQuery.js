import { ref, shallowRef, unref, watch, isRef } from 'vue'

/**
 * useQuery — TanStack Query 風のデータ取得 composable を「バニラ」で実装したもの。
 *
 * 提供する機能:
 * - data / error / isLoading / isFetching / isSuccess / isError の状態管理
 * - 同一 key に対する重複リクエストの抑止
 * - シンプルなメモリキャッシュ（key 単位、staleTime / cacheTime）
 * - 手動 refetch
 * - reactive な key の変化を監視して自動再取得（enabled / watch 対応）
 *
 * 外部ライブラリ（vue-query 等）には依存しない。
 *
 * @param {Object} options
 * @param {() => (string|Array)} options.key  キャッシュキー（関数 or ref）。配列可。
 * @param {(ctx) => Promise<any>} options.queryFn  実際にデータを取得する非同期関数
 * @param {boolean|Ref<boolean>} [options.enabled=true]  false の間は実行しない
 * @param {number} [options.staleTime=0]  この時間(ms)以内は再取得せずキャッシュを返す
 * @param {number} [options.cacheTime=300000]  キャッシュ保持時間(ms)
 * @param {Function} [options.onSuccess]
 * @param {Function} [options.onError]
 */

// key 単位のグローバルキャッシュ（モジュールスコープで共有）
const queryCache = new Map() // key -> { data, updatedAt, promise }

function normalizeKey(rawKey) {
  const value = typeof rawKey === 'function' ? rawKey() : unref(rawKey)
  return Array.isArray(value) ? JSON.stringify(value) : String(value)
}

export function useQuery(options) {
  const {
    key,
    queryFn,
    enabled = true,
    staleTime = 0,
    cacheTime = 5 * 60 * 1000,
    onSuccess,
    onError,
  } = options

  const data = shallowRef(undefined)
  const error = shallowRef(null)
  const isLoading = ref(false) // 初回ロード（キャッシュなし）
  const isFetching = ref(false) // バックグラウンド含む取得中
  const isSuccess = ref(false)
  const isError = ref(false)

  function isEnabled() {
    return typeof enabled === 'function' ? enabled() : unref(enabled)
  }

  async function execute({ force = false } = {}) {
    if (!isEnabled()) return

    const cacheKey = normalizeKey(key)
    const cached = queryCache.get(cacheKey)

    // staleTime 以内のキャッシュがあればそれを返す
    if (!force && cached && cached.data !== undefined) {
      const age = Date.now() - cached.updatedAt
      if (age < staleTime) {
        data.value = cached.data
        isSuccess.value = true
        return cached.data
      }
    }

    // 同一キーで進行中のリクエストがあれば相乗りする（重複抑止）
    if (!force && cached && cached.promise) {
      isFetching.value = true
      try {
        const result = await cached.promise
        data.value = result
        isSuccess.value = true
        return result
      } finally {
        isFetching.value = false
      }
    }

    // 初回（キャッシュなし）は isLoading を立てる
    if (data.value === undefined) isLoading.value = true
    isFetching.value = true
    isError.value = false
    error.value = null

    const promise = Promise.resolve().then(() => queryFn({ key: cacheKey }))
    queryCache.set(cacheKey, { ...(cached || {}), promise })

    try {
      const result = await promise
      data.value = result
      isSuccess.value = true
      queryCache.set(cacheKey, { data: result, updatedAt: Date.now(), promise: null })

      // cacheTime 経過後にキャッシュを破棄
      if (cacheTime > 0 && cacheTime !== Infinity) {
        setTimeout(() => {
          const entry = queryCache.get(cacheKey)
          if (entry && Date.now() - entry.updatedAt >= cacheTime) {
            queryCache.delete(cacheKey)
          }
        }, cacheTime)
      }

      if (onSuccess) onSuccess(result)
      return result
    } catch (e) {
      error.value = e
      isError.value = true
      isSuccess.value = false
      // 失敗した promise はキャッシュから外す
      const entry = queryCache.get(cacheKey)
      if (entry) queryCache.set(cacheKey, { ...entry, promise: null })
      if (onError) onError(e)
      throw e
    } finally {
      isLoading.value = false
      isFetching.value = false
    }
  }

  function refetch() {
    return execute({ force: true })
  }

  // reactive な key / enabled の変化を監視して自動再取得
  const watchSources = []
  if (isRef(key) || typeof key === 'function') watchSources.push(() => normalizeKey(key))
  if (isRef(enabled) || typeof enabled === 'function') watchSources.push(() => isEnabled())
  if (watchSources.length) {
    watch(watchSources, () => {
      if (isEnabled()) execute()
    })
  }

  return {
    data,
    error,
    isLoading,
    isFetching,
    isSuccess,
    isError,
    execute,
    refetch,
  }
}

/** 指定キー（前方一致）のキャッシュを破棄するユーティリティ。 */
export function invalidateQueries(prefix) {
  for (const k of queryCache.keys()) {
    if (k.includes(prefix)) queryCache.delete(k)
  }
}
