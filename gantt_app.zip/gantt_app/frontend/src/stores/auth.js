import { defineStore } from 'pinia'
import { ref } from 'vue'
import * as api from '../api/gantt'

/** 認証状態を管理する Pinia ストア。 */
export const useAuthStore = defineStore('auth', () => {
  const user = ref(null)
  const initializing = ref(true)
  const loginError = ref('')

  /** アプリ起動時に既存セッションを確認する。 */
  async function init() {
    initializing.value = true
    try {
      await api.fetchCsrf()
      user.value = await api.fetchMe()
    } catch {
      user.value = null
    } finally {
      initializing.value = false
    }
  }

  async function login(username, password) {
    loginError.value = ''
    try {
      await api.fetchCsrf()
      user.value = await api.login(username, password)
      return true
    } catch (e) {
      loginError.value = e?.response?.data?.detail || 'ログインに失敗しました。'
      return false
    }
  }

  async function logout() {
    try {
      await api.logout()
    } finally {
      user.value = null
    }
  }

  return { user, initializing, loginError, init, login, logout }
})
